import SimpleITK as sitk
from multiprocessing import Pool
import os
import h5py
import numpy as np
from scipy import ndimage

patch_r = 8
d1 = patch_r
d2 = patch_r*6
d3 = patch_r*6

dFA = [d1,d2,d3]  # size of patches of input data
dSeg = [d1,d2,d3] # size of pathes of label data
print dFA
step1 = 1
step2 = 1
step3 = 1
step=[step1,step2,step3]
'''
Actually, we donot need it any more,  this is useful to generate hdf5 database
'''
def convert_label(label_img):
    label_processed = np.zeros(label_img.shape[0:]).astype(np.uint8)
    for i in range(label_img.shape[2]):
        label_slice = label_img[:,:,i]
        label_slice[label_slice == 10] = 1
        label_slice[label_slice == 150] = 2
        label_slice[label_slice == 250] = 3
        label_processed[:,:,i] = label_slice
    return label_processed

def cropCubic(matPr32,matPr144,matSeg,fileID,d,step,rate,TrainDataPath,numclass,numofclass):
    # T1 mat, Segmat,
    [row,col,leng] = matPr32.shape   # read the size of matT1.
    # randnum0 = 0
    cubicCnt00 = 0                   # the number of cubic.
    estNum00 = 20000000                # 1000000 blocks for every T1/T2 image.
    patchLocation00 = np.zeros([estNum00,3],dtype=np.int16)

    cubicCnt01 = 0                   # the number of cubic.
    estNum01 = 20000000                 # 1000000 blocks for every T1/T2 image.
    patchLocation01 = np.zeros([estNum01,3],dtype=np.int16)

    cubicCnt10 = 0                   # the number of cubic.
    estNum10 = 15000000                 # 1000000 blocks for every T1/T2 image.
    patchLocation10 = np.zeros([estNum10,3],dtype=np.int16)

    cubicCnt11 = 0                   # the number of cubic.
    estNum11 = 15000000                 # 1000000 blocks for every T1/T2 image.
    patchLocation11 = np.zeros([estNum11,3],dtype=np.int16)

    cubicCnt = 0                   # the number of cubic.
    estNum = 1000000                 # 1000000 blocks for every T1/T2 image.
    trainPr32 = np.zeros([estNum,1, dFA[0],dFA[1],dFA[2]],dtype=np.int16)
    trainPr144 = np.zeros([estNum,1, dFA[0],dFA[1],dFA[2]],dtype=np.int16)
    trainSeg = np.zeros([estNum,1,dSeg[0],dSeg[1],dSeg[2]],dtype=np.uint8)

    patchLocation = np.zeros([estNum,3],dtype=np.int16)
    print 'trainPr shape, ',trainPr32.shape

    # to pad for input
    margin1 = (dFA[0]-dSeg[0])/2
    margin2 = (dFA[1]-dSeg[1])/2
    margin3 = (dFA[2]-dSeg[2])/2

    print 'matSeg shape is ',matSeg.shape
    marginD = [margin1,margin2,margin3]
    matT1Out32 = np.zeros([row+2*marginD[0],col+2*marginD[1],leng+2*marginD[2]])
    matT1Out32[marginD[0]:row+marginD[0],marginD[1]:col+marginD[1],marginD[2]:leng+marginD[2]] = matPr32
    matT1Out144 = np.zeros([row+2*marginD[0],col+2*marginD[1],leng+2*marginD[2]])
    matT1Out144[marginD[0]:row+marginD[0],marginD[1]:col+marginD[1],marginD[2]:leng+marginD[2]] = matPr144
    matSegOut = np.zeros([row+2*marginD[0],col+2*marginD[1],leng+2*marginD[2]])
    matSegOut[marginD[0]:row+marginD[0],marginD[1]:col+marginD[1],marginD[2]:leng+marginD[2]] = matSeg
    matPlot = np.zeros([row+2*marginD[0],col+2*marginD[1],leng+2*marginD[2]],dtype = np.uint8)

    dsfactor = rate
    # patch division
    for i in range(dSeg[0]/2,row-dSeg[0]/2,step[0]):
        for j in range(dSeg[1]/2,col-dSeg[1]/2,step[1]):
            for k in range(dSeg[2]/2,leng-dSeg[2]/2,step[2]):
                volCount = matSeg[i-1:i+2,j-1:j+2,k-1:k+2]

                if matSeg[i,j,k] == 0:
                    if np.sum(volCount) > 0:
                        patchLocation00[cubicCnt00,:] = [i,j,k]
                        cubicCnt00 = cubicCnt00 + 1
                    else:
                        patchLocation01[cubicCnt01,:] = [i,j,k]
                        cubicCnt01 = cubicCnt01 + 1

                elif matSeg[i,j,k] == 1:
                    if np.sum(volCount) !=27:
                        patchLocation10[cubicCnt10,:] = [i,j,k]
                        cubicCnt10 = cubicCnt10 + 1
                    else:
                        patchLocation11[cubicCnt11,:] = [i,j,k]
                        cubicCnt11 = cubicCnt11 + 1

    print cubicCnt00,cubicCnt01,cubicCnt10,cubicCnt11

    patchLocation00 = patchLocation00[0:cubicCnt00,:]
    randnum00 = range(cubicCnt00)
    np.random.shuffle(randnum00)
    randnum00 = randnum00[0:(numofclass*4)/5]
    patchLocation00 = patchLocation00[randnum00,:]
    patchLocation01 = patchLocation01[0:cubicCnt01,:]
    randnum01 = range(cubicCnt01)
    np.random.shuffle(randnum01)
    randnum01 = randnum01[0:(numofclass*1)/5]
    patchLocation01 = patchLocation01[randnum01,:]

    patchLocation10 = patchLocation10[0:cubicCnt10,:]
    randnum10 = range(cubicCnt10)
    np.random.shuffle(randnum10)
    randnum10 = randnum10[0:(numofclass*4)/5]
    patchLocation10 = patchLocation10[randnum10,:]
    patchLocation11 = patchLocation11[0:cubicCnt11,:]
    randnum11 = range(cubicCnt11)
    np.random.shuffle(randnum11)
    randnum11 = randnum11[0:(numofclass*1)/5]
    patchLocation11 = patchLocation11[randnum11,:]

    cubicCnt = numclass*numofclass

    patchLocation[0:(numofclass*4)/5,:] = patchLocation00
    patchLocation[(numofclass*4)/5:numofclass,:] = patchLocation01

    patchLocation[numofclass:(numofclass+(numofclass*4)/5),:] = patchLocation10
    patchLocation[(numofclass+(numofclass*4)/5):2*numofclass,:] = patchLocation11

    print('Num_of_patches=%d'%cubicCnt)

    for i_l in range(cubicCnt):
        [row,col,leng] = patchLocation[i_l,:]
        matPlot[row,col,leng] = 1
        volSeg = matSeg[row-dSeg[0]/2:row+dSeg[0]/2,col-dSeg[1]/2:col+dSeg[1]/2,leng-dSeg[2]/2:leng+dSeg[2]/2]
        volPr32 = matT1Out32[row-dFA[0]/2:row+dFA[0]/2,col-dFA[1]/2:col+dFA[1]/2,leng-dFA[2]/2:leng+dFA[2]/2]
        volPr144 = matT1Out144[row-dFA[0]/2:row+dFA[0]/2,col-dFA[1]/2:col+dFA[1]/2,leng-dFA[2]/2:leng+dFA[2]/2]
        trainSeg[i_l,0,:,:,:] = volSeg
        trainPr32[i_l,0,:,:,:] = volPr32
        trainPr144[i_l,0,:,:,:] = volPr144

    trainPr32 = trainPr32[0:cubicCnt,:,:,:,:]
    trainPr144 = trainPr144[0:cubicCnt,:,:,:,:]
    trainSeg = trainSeg[0:cubicCnt,:,:,:,:]

    patchfileName=os.path.join(TrainDataPath,'trainMS_%s.h5'%fileID)
    txtfileTrainName=os.path.join(TrainDataPath,'trainMS_list.txt')
    txtfileValidationName=os.path.join(TrainDataPath,'testMS_list.txt')
    if os.path.isfile(patchfileName):
        os.remove(patchfileName)

    with h5py.File(patchfileName,'w') as f:
        f['dataPr32']=trainPr32
        f['dataPr144']=trainPr144
        f['dataSeg']=trainSeg

    if fileID == '0':
        with open(txtfileValidationName,'a') as f:
            f.write(patchfileName+'\n')
    elif fileID == '1':
        with open(txtfileValidationName,'a') as f:
            f.write(patchfileName+'\n')
    elif fileID == '2':
        with open(txtfileValidationName,'a') as f:
            f.write(patchfileName+'\n')
    elif fileID == '3':
        with open(txtfileValidationName,'a') as f:
            f.write(patchfileName+'\n')
    elif fileID == '4':
        with open(txtfileValidationName,'a') as f:
            f.write(patchfileName+'\n')
    elif fileID == '5':
        with open(txtfileValidationName,'a') as f:
            f.write(patchfileName+'\n')
    else:
        with open(txtfileTrainName,'a') as f:
            f.write(patchfileName+'\n')

    return cubicCnt,matPlot

def main():
    data_path = '***/Your training data path here/***'
    TrainDataPath = '***/You store your training patches here/***'
    txtfileName = os.path.join(TrainDataPath,'trainMS_list.txt')
    txtfileValidationName = os.path.join(TrainDataPath,'testMS_list.txt')
    if not os.path.isdir(TrainDataPath):
        os.mkdir(TrainDataPath)
    if os.path.isfile(txtfileName):
        os.remove(txtfileName)
    if os.path.isfile(txtfileValidationName):
        os.remove(txtfileValidationName)

    items = os.listdir(".")
    newlist = []
    ids = set()
    for names in items:
        if names.endswith("-label.nii.gz"):
            newlist.append(names)

    for f in newlist:
        ids.add(f.split('-label.nii.gz')[0])
    ids = list(ids)
    print ids
    for idn in range(len(ids)):

        subject_name = ids[idn]
        print(subject_name)

        f_Pr32 = os.path.join(data_path,'%s-Pr1.nii.gz'%subject_name);
        imgPr32_Org = sitk.ReadImage(f_Pr32)
        imgPr32 = sitk.GetArrayFromImage(imgPr32_Org)
        [rowN,colN,lengN] = imgPr32.shape
        imgPr3216 = 65535*np.array(imgPr32)
        imgPr3232 = np.zeros([rowN,colN,lengN],dtype=np.int16)
        imgPr3232 = imgPr3216


        f_Pr144 = os.path.join(data_path,'%s-1-Pr1.nii.gz'%subject_name);
        imgPr144_Org = sitk.ReadImage(f_Pr144)
        imgPr144 = sitk.GetArrayFromImage(imgPr144_Org)
        imgPr14416 = 65535*np.array(imgPr144)
        imgPr144144 = np.zeros([rowN,colN,lengN],dtype=np.int16)
        imgPr144144 = imgPr14416

        f_L = os.path.join(data_path,'%s-label.nii.gz'%subject_name);
        label_Org = sitk.ReadImage(f_L)
        labelimg = sitk.GetArrayFromImage(label_Org)

        fileID='%d'%idn
        rate = 1

        cubicCnt,matplot = cropCubic(imgPr3232,imgPr144144,labelimg,fileID,dFA,step,rate,TrainDataPath,2,1500)

        volOut = sitk.GetImageFromArray(matplot)
        volOut.SetSpacing(label_Org.GetSpacing())

        sitk.WriteImage(volOut,'./%s-plot.nii.gz'%subject_name)

    print('done')
if __name__ == '__main__':
    main()
