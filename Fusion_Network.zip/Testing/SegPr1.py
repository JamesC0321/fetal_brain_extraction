import SimpleITK as sitk
from multiprocessing import Pool
import os
import h5py
import numpy as np
import scipy.io as scio
from scipy import ndimage as nd
from skimage.morphology import remove_small_objects
from skimage.morphology import remove_small_holes

caffe_root = '/usr/local/caffe3/'
import sys
sys.path.insert(0, caffe_root + 'python')
print caffe_root + 'python'
import caffe
# very important, select GPU device
caffe.set_device(6)
# set gpu mode
caffe.set_mode_gpu()
# load the solver and create train and test nets
# ignore this workaround for lmdb data (can't instantiate two solvers on the same data)
solver = None
protopath='***/Your prototxt path here/***'
modelpath='***/Your caffemodel path here/***'
mynet = caffe.Net(protopath+'deploy_SimpleNet.prototxt',modelpath+'Your caffemodel name.caffemodel',caffe.TEST)
print("blobs {}\nparams {}".format(mynet.blobs.keys(), mynet.params.keys()))

patch_r=8
d1=patch_r
d2=patch_r*6
d3=patch_r*6
dFA=[d1,d2,d3] # size of patches of input data

dSeg=[patch_r,patch_r,patch_r] # size of pathes of label data
step1=2
step2=12
step3=12
step=[step1,step2,step3]

#the number of classes in this segmentation project
NumOfClass=2

def convert_label(label_img):
    label_processed = np.zeros(label_img.shape[0:]).astype(np.uint8)
    for i in range(label_img.shape[2]):
        label_slice = label_img[:,:,i]
        label_slice[label_slice == 10] = 1
        label_slice[label_slice == 150] = 2
        label_slice[label_slice == 250] = 3
        label_processed[:,:,i] = label_slice
    return label_processed

def cropCubic(mat32,mat144,fileID,d,step,rate):
    eps=1e-5
    [row,col,leng]=mat32.shape
    cubicCnt=0

    print 'mat shape is ',mat32.shape
    mat32Out = mat32
    mat144Out = mat144

    mat32OutScale = nd.interpolation.zoom(mat32Out, zoom=rate)
    mat144OutScale = nd.interpolation.zoom(mat144Out, zoom=rate)
    matSegScale=nd.interpolation.zoom(mat32Out, zoom=rate)

    matOut=np.zeros((matSegScale.shape[0],matSegScale.shape[1],matSegScale.shape[2],NumOfClass))
    PrOut=np.zeros((matSegScale.shape[0],matSegScale.shape[1],matSegScale.shape[2],NumOfClass))

    for i in range(1,matSegScale.shape[0]-d[0],step[0]):
        for j in range(1,matSegScale.shape[1]-d[1],step[1]):
            for k in range(1,matSegScale.shape[2]-d[2],step[2]):

                vol32 = mat32OutScale[i:i+d[0],j:j+d[1],k:k+d[2]]
                vol144 = mat144OutScale[i:i+d[0],j:j+d[1],k:k+d[2]]

                mynet.blobs['dataPr32'].data[0,0,...]=vol32
                mynet.blobs['dataPr144'].data[0,0,...]=vol144

                mynet.forward()

                temppremat = mynet.blobs['softmax'].data[0].argmax(axis=0) #Note you have add softmax layer in deploy prototxt
                tempprob = mynet.blobs['softmax'].data[0] # probobility.

                for labelInd in range(NumOfClass):
                    currLabelMat = np.where(temppremat==labelInd, 1, 0)
                    matOut[i:i+d[0],j:j+d[1],k:k+d[2],labelInd]=matOut[i:i+d[0],j:j+d[1],k:k+d[2],labelInd]+currLabelMat
                    PrOut[i:i+d[0],j:j+d[1],k:k+d[2],labelInd]=PrOut[i:i+d[0],j:j+d[1],k:k+d[2],labelInd]+tempprob[labelInd,:,:,:]

    sumOut=PrOut.sum(axis=3)

    PrOut0=PrOut[:,:,:,0]/(sumOut+eps)
    PrOut1=PrOut[:,:,:,1]/(sumOut+eps)

    matOut=matOut.argmax(axis=3) #always 3
    matOut=np.rint(matOut) #this line is necessary, it is very important, because it will convert datatype to make the nii.gz correct, otherwise, will appear strage shape
    return matOut,PrOut0,PrOut1

def removesmall(matRed,matmask1):
    [row,col,leng]=matmask1.shape
    print('matT1 shape is ',matmask1.shape)
    matT1Out = matmask1
    for i in range(0,row,1):
        for j in range(0,col,1):
            for k in range(0,leng,1):
                if matmask1[i,j,k] == 1 and matRed[i,j,k] != 1:
                    matT1Out[i,j,k] = 0
                else:
                    matT1Out[i,j,k] = matmask1[i,j,k]
    return matT1Out

#this function is used to compute the dice ratio
def dice(im1, im2,tid):
    im1=im1==tid #make it boolean
    im2=im2==tid #make it boolean
    im1=np.asarray(im1).astype(np.bool)
    im2=np.asarray(im2).astype(np.bool)

    if im1.shape != im2.shape:
        raise ValueError("Shape mismatch: im1 and im2 must have the same shape.")
    # Compute Dice coefficient
    intersection = np.logical_and(im1, im2)
    dsc=2. * intersection.sum() / (im1.sum() + im2.sum())
    return dsc


def main():

    data_path = '***/Your data path here/***'
    items = os.listdir(".")
    newlist = []
    ids = set()
    for names in items:
        if names.endswith("-1-Pr1.nii.gz"):
            newlist.append(names)

    for f in newlist:
        ids.add(f.split('-1-Pr1.nii.gz')[0])
    ids = list(ids)
    print ids

    for idn in range(len(ids)):
        subject_name = ids[idn]
        print(subject_name)
        #n4 operation
        Pr_32 = os.path.join(data_path,'%s-Pr1.nii.gz'%subject_name)
        Pr_32_Org = sitk.ReadImage(Pr_32)
        imgPr3232 = sitk.GetArrayFromImage(Pr_32_Org)

        [rowN,colN,lengN] = imgPr3232.shape

        Pr_144 = os.path.join(data_path,'%s-1-Pr1.nii.gz'%subject_name)
        Pr_144_Org = sitk.ReadImage(Pr_144)
        imgPr144144 = sitk.GetArrayFromImage(Pr_144_Org)

        fileID='%s'%subject_name
        rate=1

        matOut,PrOut0,PrOut1=cropCubic(imgPr3232,imgPr144144,fileID,dFA,step,rate)

        volOutLabel=sitk.GetImageFromArray(matOut)
        volPr0=sitk.GetImageFromArray(PrOut0)
        volPr1=sitk.GetImageFromArray(PrOut1)

        sitk.WriteImage(volOutLabel,'./%s-Seg.nii.gz' % subject_name)
        sitk.WriteImage(volPr0,'./%s-2-Pr02.nii.gz' % subject_name)
        sitk.WriteImage(volPr1,'./%s-2-Pr12.nii.gz' % subject_name)

        f_L_1 = os.path.join(data_path,'%s-DEN2.nii.gz'%subject_name);
        imgT1_S_Label=sitk.ReadImage(f_L_1)
        imgT1_Label_1=sitk.GetArrayFromImage(imgT1_S_Label)

        imgT1_Red = imgT1_Label_1.copy()
        imgT1_Red[:,:,:] = remove_small_objects(imgT1_Red[:,:,:]==1,int((imgT1_Red[:,:,:]==1).sum()/2.0)) 
        imgT1_K = removesmall(imgT1_Red,imgT1_Label_1)

        Out=sitk.GetImageFromArray(imgT1_K)
        sitk.WriteImage(Out,'./%s-SegFinal.nii.gz'%subject_name)

if __name__ == '__main__':
    main()
