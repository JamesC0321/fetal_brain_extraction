import SimpleITK as sitk
from multiprocessing import Pool
import os
import h5py
import numpy as np  
import scipy.io as scio
from scipy import ndimage as nd
from skimage.morphology import remove_small_objects
from skimage.morphology import remove_small_holes
# Make sure that caffe is on the python path:

caffe_root = '/usr/local/caffe3/'
import sys
sys.path.insert(0, caffe_root + 'python')
print caffe_root + 'python'
import caffe
# very important, select GPU device
caffe.set_device(7)
# set gpu mode
caffe.set_mode_gpu()
# load the solver and create train and test nets
# ignore this workaround for lmdb data (can't instantiate two solvers on the same data)
solver = None  
protopath='***/Your path for prototxt/***'
modelpath='***/Your path for caffemodel/***'
mynet = caffe.Net(protopath+'deployMask84848.prototxt',modelpath+'Name of caffemodel for whole image.caffemodel',caffe.TEST)
mynet1 = caffe.Net(protopath+'deployMask84848.prototxt',modelpath+'Name of caffemodel for ROI image.caffemodel',caffe.TEST)
print("blobs {}\nparams {}".format(mynet.blobs.keys(), mynet.params.keys()))

patch_r=8
d1=patch_r
d2=patch_r*6
d3=patch_r*6
dFA=[d1,d2,d3] # size of patches of input data
dSeg=[patch_r,patch_r,patch_r] # size of pathes of label data
step1=2	
step2=12
step3=12
step=[step1,step2,step3]

#the number of classes in this segmentation project
NumOfClass=2

def convert_label(label_img):
    label_processed = np.zeros(label_img.shape[0:]).astype(np.uint8)
    for i in range(label_img.shape[2]):
        label_slice = label_img[:,:,i]
        label_slice[label_slice == 10] = 1
        label_slice[label_slice == 150] = 2
        label_slice[label_slice == 250] = 3
        label_processed[:,:,i] = label_slice
    return label_processed

def hist_match(img,temp):
    ''' histogram matching from img to temp '''
    matcher = sitk.HistogramMatchingImageFilter()
    matcher.SetNumberOfHistogramLevels(1024)
    matcher.SetNumberOfMatchPoints(7)
    matcher.ThresholdAtMeanIntensityOn()
    res = matcher.Execute(img,temp)
    return res

def cropCubic(matT1,fileID,d,step,rate):
    eps=1e-5
    [row,col,leng]=matT1.shape
    cubicCnt=0
        
    print 'matT1 shape is ',matT1.shape
    matT1Out = matT1
    matT1OutScale = nd.interpolation.zoom(matT1Out, zoom=rate)
    matSegScale=nd.interpolation.zoom(matT1Out, zoom=rate)

    matOut=np.zeros((matSegScale.shape[0],matSegScale.shape[1],matSegScale.shape[2],NumOfClass))
    PrOut=np.zeros((matSegScale.shape[0],matSegScale.shape[1],matSegScale.shape[2],NumOfClass))

    for i in range(1,matSegScale.shape[0]-d[0],step[0]):
        for j in range(1,matSegScale.shape[1]-d[1],step[1]):
            for k in range(1,matSegScale.shape[2]-d[2],step[2]):
         
                volT1 = matT1OutScale[i:i+d[0],j:j+d[1],k:k+d[2]]    
                mynet.blobs['dataT1'].data[0,0,...]=volT1
                mynet.forward()
                temppremat = mynet.blobs['softmax'].data[0].argmax(axis=0) #Note you have add softmax layer in deploy prototxt
                tempprob = mynet.blobs['softmax'].data[0] # probobility.

                for labelInd in range(NumOfClass): 
                    currLabelMat = np.where(temppremat==labelInd, 1, 0) 
                    matOut[i:i+d[0],j:j+d[1],k:k+d[2],labelInd]=matOut[i:i+d[0],j:j+d[1],k:k+d[2],labelInd]+currLabelMat
                    PrOut[i:i+d[0],j:j+d[1],k:k+d[2],labelInd]=PrOut[i:i+d[0],j:j+d[1],k:k+d[2],labelInd]+tempprob[labelInd,:,:,:]

    sumOut=PrOut.sum(axis=3)
    
    PrOut0=PrOut[:,:,:,0]/(sumOut+eps)
    PrOut1=PrOut[:,:,:,1]/(sumOut+eps)
    matOut=matOut.argmax(axis=3) #always 3
    matOut=np.rint(matOut) #this line is necessary, it is very important, because it will convert datatype to make the nii.gz correct, otherwise, will appear strage shape
    ##############################################change
    return matOut, PrOut0, PrOut1

def cropCubic1(matT1,fileID,d,step,rate):
    eps=1e-5
    [row,col,leng]=matT1.shape
    cubicCnt=0
        
    print 'matT1 shape is ',matT1.shape
    matT1Out = matT1
    matT1OutScale = nd.interpolation.zoom(matT1Out, zoom=rate)
    matSegScale=nd.interpolation.zoom(matT1Out, zoom=rate)

    matOut=np.zeros((matSegScale.shape[0],matSegScale.shape[1],matSegScale.shape[2],NumOfClass))
    PrOut=np.zeros((matSegScale.shape[0],matSegScale.shape[1],matSegScale.shape[2],NumOfClass))

    for i in range(1,matSegScale.shape[0]-d[0],step[0]):
        for j in range(1,matSegScale.shape[1]-d[1],step[1]):
            for k in range(1,matSegScale.shape[2]-d[2],step[2]):
         
                volT1 = matT1OutScale[i:i+d[0],j:j+d[1],k:k+d[2]]    
                mynet1.blobs['dataT1'].data[0,0,...]=volT1
                mynet1.forward()
                temppremat = mynet1.blobs['softmax'].data[0].argmax(axis=0) #Note you have add softmax layer in deploy prototxt
                tempprob = mynet1.blobs['softmax'].data[0] # probobility.

                for labelInd in range(NumOfClass): 
                    currLabelMat = np.where(temppremat==labelInd, 1, 0) 
                    matOut[i:i+d[0],j:j+d[1],k:k+d[2],labelInd]=matOut[i:i+d[0],j:j+d[1],k:k+d[2],labelInd]+currLabelMat
                    PrOut[i:i+d[0],j:j+d[1],k:k+d[2],labelInd]=PrOut[i:i+d[0],j:j+d[1],k:k+d[2],labelInd]+tempprob[labelInd,:,:,:]

    sumOut=PrOut.sum(axis=3)
    
    PrOut0=PrOut[:,:,:,0]/(sumOut+eps)
    PrOut1=PrOut[:,:,:,1]/(sumOut+eps)
    matOut=matOut.argmax(axis=3) #always 3
    matOut=np.rint(matOut) #this line is necessary, it is very important, because it will convert datatype to make the nii.gz correct, otherwise, will appear strage shape
    return matOut,PrOut0,PrOut1

def calculatepoint(img,imglabel):
    #return img
    [row,col,leng] = img.shape   # read the size of matT1.
    col1 = col/6
    leng1 = leng/6
    print(col1,leng1)
    matimg = np.zeros([row,col1*2,leng1*2],dtype = np.int16)
    matlabel = np.zeros([row,col1*2,leng1*2],dtype = np.uint8)
    num = 0
    midcol = 0
    midleng = 0

    for i in range(0, row, 1):
        for j in range(0, col, 1):
            for k in range(0, leng, 1):
            	if imglabel[i,j,k] == 1:
            		num = int(num) + 1
            		midcol = int(midcol) + j
            		midleng = int(midleng) + k
    print (midcol,midleng,num)
    midcol = midcol/num
    midleng = midleng/num
    print (midcol,midleng)
    if (midcol - col1) < 0:
    	colleft = 0
    else:
    	colleft = midcol - col1

    if (midcol + col1) > col:
    	colright = col
    else:
    	colright = midcol + col1

    if (midleng - leng1) < 0:
    	lengleft = 0
    else:
    	lengleft = midleng - leng1

    if (midleng + leng1) > leng:
    	lengright = leng
    else:
    	lengright = midleng + leng1

    print(colleft,colright,lengleft,lengright)
    discol = col1*2 - (colright - colleft)
    disleng = leng1*2 - (lengright - lengleft)
    print(discol,disleng)
    matimg[:,discol/2:discol/2+int(colright)-int(colleft),disleng/2:disleng/2+int(lengright)-int(lengleft)] = img[:,int(colleft):int(colright),int(lengleft):int(lengright)]
    
    return matimg, colleft, colright, lengleft, lengright

def removesmall(matRed,matmask1):
    [row,col,leng]=matmask1.shape
    print('matT1 shape is ',matmask1.shape)
    matT1Out = matmask1
    for i in range(0,row,1):
        for j in range(0,col,1):
            for k in range(0,leng,1):
                if matmask1[i,j,k] == 1 and matRed[i,j,k] != 1:
                    matT1Out[i,j,k] = 0
                else:
                    matT1Out[i,j,k] = matmask1[i,j,k]
    return matT1Out

#this function is used to compute the dice ratio
def dice(im1, im2,tid):
    im1=im1==tid #make it boolean
    im2=im2==tid #make it boolean
    im1=np.asarray(im1).astype(np.bool)
    im2=np.asarray(im2).astype(np.bool)

    if im1.shape != im2.shape:
        raise ValueError("Shape mismatch: im1 and im2 must have the same shape.")
    # Compute Dice coefficient
    intersection = np.logical_and(im1, im2)
    dsc=2. * intersection.sum() / (im1.sum() + im2.sum())
    return dsc

def main():
    
    data_path = '***/Your date for segmentation/***' 
    data_path1 = '***/Your data for histogram macthing/***'
    img_standard_forhis = os.path.join(data_path1,'***Small image for histogram matching***')
    img_standard_Org = sitk.ReadImage(img_standard_forhis)
    img_standard_forhis_Big = os.path.join(data_path1,'***Big image for histogram matching***')
    img_standard_Org_Big = sitk.ReadImage(img_standard_forhis_Big)

    items = os.listdir(".")
    newlist = []
    ids = set()
    for names in items:
        if names.endswith('_resize_n4.nii.gz'):
            newlist.append(names)
    for f in newlist:
        ids.add(f.split('_resize_n4.nii.gz')[0])
    ids = list(ids)
    print ids

    for idn in range(len(ids)):
        subject_name=ids[idn]
        print(subject_name)
        #####################################################################################################
        # first segmentation #
        f_T1=os.path.join(data_path,'%s_resize_n4.nii.gz' %subject_name);
        imgT1_Org=sitk.ReadImage(f_T1)
        imgT1=sitk.GetArrayFromImage(imgT1_Org)
        [row,col,leng] = imgT1.shape

        f_L = os.path.join(data_path,'%s-label.nii.gz'%subject_name);
        imgT1_Org_Label=sitk.ReadImage(f_L)
        img_Label=sitk.GetArrayFromImage(imgT1_Org_Label)

        fileID='%02d'%idn
        rate=1
        #####################################################################################################
        # histogram matching
        Out5 = hist_match(imgT1_Org,img_standard_Org_Big)
        sitk.WriteImage(Out5,'./%s_resize_n4_his.nii.gz'%subject_name)  

        f_T1_big_his=os.path.join(data_path,'%s_resize_n4_his.nii.gz' %subject_name);
        imgT1_Org_big_His=sitk.ReadImage(f_T1_big_his)
        imgT1_big_His=sitk.GetArrayFromImage(imgT1_Org_big_His)
        ############################################change###################################################
        matOut, PrOut00, PrOut01 =cropCubic(imgT1_big_His,fileID,dFA,step,rate)
 
        volOutLabel=sitk.GetImageFromArray(matOut)
        volPr00=sitk.GetImageFromArray(PrOut00)
        volPr01=sitk.GetImageFromArray(PrOut01)

        Dice0=dice(matOut,img_Label,0)
        print('Dice0 is %f'%Dice0)
        Dice1=dice(matOut,img_Label,1)
        print('Dice1 is %f'%Dice1)
        Dice=dice(matOut>0,img_Label>0,1)
        print('Dice is %f'%Dice)
        
        sitk.WriteImage(volOutLabel,'./%s-DEN.nii.gz' % subject_name)
        sitk.WriteImage(volPr00,'./%s-1-Pr0.nii.gz' % subject_name)
        sitk.WriteImage(volPr01,'./%s-1-Pr1.nii.gz' % subject_name)
        #######################################################################################################
        # move the small blocks
        f_L_1 = os.path.join(data_path,'%s-DEN.nii.gz'%subject_name);
        imgT1_S_Label=sitk.ReadImage(f_L_1)
        imgT1_Label_1=sitk.GetArrayFromImage(imgT1_S_Label)

        imgT1_Red = imgT1_Label_1.copy()
        imgT1_Red[:,:,:] = remove_small_objects(imgT1_Red[:,:,:]==1,int((imgT1_Red[:,:,:]==1).sum()/2.0)) 
        imgT1_K = removesmall(imgT1_Red,imgT1_Label_1)
        
        Out=sitk.GetImageFromArray(imgT1_K)
        Out.SetDirection(imgT1_S_Label.GetDirection())
        Out.SetOrigin(imgT1_S_Label.GetOrigin())
        Out.SetSpacing(imgT1_S_Label.GetSpacing())
        sitk.WriteImage(Out,'./%s-DEN1.nii.gz'%subject_name)
        #######################################################################################################
        # get the small image
        f_L_2 = os.path.join(data_path,'%s-DEN1.nii.gz'%subject_name);
        imgT1_SS_Label=sitk.ReadImage(f_L_2)
        imgT1_Label_2=sitk.GetArrayFromImage(imgT1_SS_Label)

        matimg, colleft, colright, lengleft, lengright = calculatepoint(imgT1,imgT1_Label_2)
        volOutImg=sitk.GetImageFromArray(matimg)
        sitk.WriteImage(volOutImg,'./%s_resize_n4_part.nii.gz' %subject_name)
        ########################################################################################################
        # histogram matching again
        f_T1_small = os.path.join(data_path,'%s_resize_n4_part.nii.gz'%subject_name)
        img3_Org_small = sitk.ReadImage(f_T1_small)
        # his operation
        Out2 = hist_match(img3_Org_small,img_standard_Org)
        sitk.WriteImage(Out2,'./%s_resize_n4_part_his.nii.gz'%subject_name)  
        ########################################################################################################
        # second segmentation, small one
        f_T1_small_his=os.path.join(data_path,'%s_resize_n4_part_his.nii.gz'%subject_name);
        imgT1_Org_Small_His=sitk.ReadImage(f_T1_small_his)
        imgT1_Small_His=sitk.GetArrayFromImage(imgT1_Org_Small_His)

        matOut1,PrOut0,PrOut1 = cropCubic1(imgT1_Small_His,fileID,dFA,step,rate)
        matlabel = np.zeros([row,col,leng],dtype = np.uint8)        
        VPr0 = np.ones([row,col,leng])
        VPr1 = np.zeros([row,col,leng])

        [row2,col2,leng2] = matOut1.shape

        matlabel[:,colleft:colright,lengleft:lengright] = matOut1
        VPr0[1:row-1,colleft+3:colright-4,lengleft+3:lengright-4] = PrOut0[1:row2-1,3:colright-colleft-4,3:lengright-lengleft-4]
        VPr1[1:row-1,colleft+3:colright-4,lengleft+3:lengright-4] = PrOut1[1:row2-1,3:colright-colleft-4,3:lengright-lengleft-4]

        volOut1=sitk.GetImageFromArray(matlabel)
        volPr0=sitk.GetImageFromArray(VPr0)
        volPr1=sitk.GetImageFromArray(VPr1)

        Dice0=dice(matlabel,img_Label,0)
        print('Dice0 is %f'%Dice0)
        Dice1=dice(matlabel,img_Label,1)
        print('Dice1 is %f'%Dice1)
        Dice=dice(matlabel>0,img_Label>0,1)
        print('Dice is %f'%Dice)

        sitk.WriteImage(volOut1,'./%s_DENfinal.nii.gz'%subject_name) 
        sitk.WriteImage(volPr0,'./%s-Pr0.nii.gz' % subject_name)
        sitk.WriteImage(volPr1,'./%s-Pr1.nii.gz' % subject_name)

if __name__ == '__main__':     
    main()
