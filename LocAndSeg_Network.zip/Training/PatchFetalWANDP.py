import SimpleITK as sitk
from multiprocessing import Pool
import os
import h5py
import numpy as np
from scipy import ndimage

patch_r = 8
d1 = patch_r
d2 = patch_r*6
d3 = patch_r*6

dFA = [d1,d2,d3]  # size of patches of input data
dSeg = [d1,d2,d3] # size of pathes of label data
print dFA
step1 = 1
step2 = 1
step3 = 1

step=[step1,step2,step3]

def cropCubic(matT1,matSeg,fileID,d,step,rate,TrainDataPath):

    [row,col,leng] = matT1.shape   # read the size of matT1.

    cubicCntBord = 0                   # the number of cubic.
    estNumBord = 500000                 # 1000000 blocks for every T1/T2 image.
    patchLocationBord = np.zeros([estNumBord,3],dtype=np.int16)

    cubicCntInside = 0                   # the number of cubic.
    estNumInside = 30000000                 # 1000000 blocks for every T1/T2 image.
    patchLocationInside = np.zeros([estNumInside,3],dtype=np.int16)

    cubicCnt1 = 0
    estNum = 50000                 # 1000000 blocks for every T1/T2 image.
    patchLocation = np.zeros([estNum,3],dtype=np.int16)
    trainT1 = np.zeros([estNum,1, dFA[0],dFA[1],dFA[2]],dtype=np.int16)
    trainSeg = np.zeros([estNum,1,dSeg[0],dSeg[1],dSeg[2]],dtype=np.uint8)

    print 'trainT1 shape, ',trainT1.shape

    margin1 = (dFA[0]-dSeg[0])/2
    margin2 = (dFA[1]-dSeg[1])/2
    margin3 = (dFA[2]-dSeg[2])/2

    print 'matSeg shape is ',matSeg.shape
    marginD = [margin1,margin2,margin3]
    print 'matT1 shape is ',matT1.shape
    matT1Out = np.zeros([row+2*marginD[0],col+2*marginD[1],leng+2*marginD[2]])
    print 'matT1Out shape is ',matT1Out.shape
    matT1Out[marginD[0]:row+marginD[0],marginD[1]:col+marginD[1],marginD[2]:leng+marginD[2]] = matT1
    matSegOut = np.zeros([row+2*marginD[0],col+2*marginD[1],leng+2*marginD[2]])
    matSegOut[marginD[0]:row+marginD[0],marginD[1]:col+marginD[1],marginD[2]:leng+marginD[2]] = matSeg
    matPlot = np.zeros([row+2*marginD[0],col+2*marginD[1],leng+2*marginD[2]],dtype = np.uint8)
    dsfactor = rate
    for i in range(dSeg[0]/2,row-dSeg[0]/2,step[0]):
        for j in range(dSeg[1]/2,col-dSeg[1]/2,step[1]):
            for k in range(dSeg[2]/2,leng-dSeg[2]/2,step[2]):
                volSeg = matSeg[i-dSeg[0]/2:i+dSeg[0]/2,j-dSeg[1]/2:j+dSeg[1]/2,k-dSeg[2]/2:k+dSeg[2]/2]
                volT1 = matT1[i-dSeg[0]/2:i+dSeg[0]/2,j-dSeg[1]/2:j+dSeg[1]/2,k-dSeg[2]/2:k+dSeg[2]/2]
                volCount = matSeg[(i-2):(i+3),(j-2):(j+3),(k-2):(k+3)]
                if np.sum(volT1) == 0:
                     continue
                if matSeg[i,j,k] == 0 and np.sum(volCount>0) > 0:
                    patchLocationBord[cubicCntBord,:] = [i,j,k]
                    cubicCntBord = cubicCntBord + 1
                elif matSeg[i,j,k] == 1 and np.sum(volCount>0) < 125:
                    patchLocationBord[cubicCntBord,:] = [i,j,k]
                    cubicCntBord = cubicCntBord + 1
                else:
                    patchLocationInside[cubicCntInside,:] = [i,j,k]
                    cubicCntInside = cubicCntInside + 1
                
    patchLocationBord = patchLocationBord[0:cubicCntBord,:]
    randnumBord = range(cubicCntBord)
    np.random.shuffle(randnumBord)
    nSelBord = cubicCntBord//150
    randnumBord = randnumBord[0:nSelBord]
    patchLocationBord = patchLocationBord[randnumBord,:]

    patchLocationInside = patchLocationInside[0:cubicCntInside,:]
    randnumInside = range(cubicCntInside)
    np.random.shuffle(randnumInside)
    if (nSelBord) < cubicCntInside:
        randnumInside = randnumInside[0:(nSelBord)]
    patchLocationInside = patchLocationInside[randnumInside,:]

    cubicCnt1 = len(randnumBord) + len(randnumInside)

    patchLocation[0:len(randnumBord),:] = patchLocationBord
    patchLocation[len(randnumBord):cubicCnt1,:] = patchLocationInside
    patchLocation = patchLocation[0:cubicCnt1,:]

    print('Num_of_patches=%d'%cubicCnt1)
    print len(randnumBord), len(randnumInside)

    for i_l in range(cubicCnt1):
        [row,col,leng] = patchLocation[i_l,:]
        matPlot[row,col,leng] = 1
        volSeg = matSeg[row-dSeg[0]/2:row+dSeg[0]/2,col-dSeg[1]/2:col+dSeg[1]/2,leng-dSeg[2]/2:leng+dSeg[2]/2]
        volT1 = matT1Out[row-dFA[0]/2:row+dFA[0]/2,col-dFA[1]/2:col+dFA[1]/2,leng-dFA[2]/2:leng+dFA[2]/2]
        trainT1[i_l,0,:,:,:] = volT1
        trainSeg[i_l,0,:,:,:] = volSeg

    trainT1 = trainT1[0:cubicCnt1,:,:,:,:]
    trainSeg = trainSeg[0:cubicCnt1,:,:,:,:]

    patchfileName=os.path.join(TrainDataPath,'trainMS_%s.h5'%fileID)
    txtfileTrainName=os.path.join(TrainDataPath,'trainMS_list.txt')
    txtfileValidationName=os.path.join(TrainDataPath,'testMS_list.txt')
    if os.path.isfile(patchfileName):
        os.remove(patchfileName)
    # open the file patchfileName as w model
    with h5py.File(patchfileName,'w') as f:
        f['dataT1']=trainT1
        f['dataSeg']=trainSeg

    if fileID == '0':
        with open(txtfileValidationName,'a') as f:
            f.write(patchfileName+'\n')
    elif fileID == '1':
        with open(txtfileValidationName,'a') as f:
            f.write(patchfileName+'\n')
    elif fileID == '2':
        with open(txtfileValidationName,'a') as f:
            f.write(patchfileName+'\n')
    else:
        with open(txtfileTrainName,'a') as f:
            f.write(patchfileName+'\n')

    return cubicCnt1, matPlot

def main():
    data_path = '***/Your training data here/***'
    TrainDataPath = '***/Your training pathes here/***'
    txtfileName = os.path.join(TrainDataPath,'trainMS_list.txt')
    txtfileValidationName = os.path.join(TrainDataPath,'testMS_list.txt') 
    if not os.path.isdir(TrainDataPath):
        os.mkdir(TrainDataPath)
    if os.path.isfile(txtfileName):
        os.remove(txtfileName)
    if os.path.isfile(txtfileValidationName):
        os.remove(txtfileValidationName)

    items = os.listdir(".")
    newlist = []
    ids = set()
    for names in items:
        if names.endswith("_resize_n4_part_his.nii.gz"):
            newlist.append(names)

    for f in newlist:
        ids.add(f.split('_resize_n4_part_his.nii.gz')[0])
    ids = list(ids)
    print(ids)

    for idn in range(len(ids)):

        subject_name = ids[idn]
        print(subject_name)
        f_T1 = os.path.join(data_path,'%s_resize_n4_part_his.nii.gz'%subject_name);
        f_L = os.path.join(data_path,'%s-label_part.nii.gz'%subject_name);

        imgT1_Org = sitk.ReadImage(f_T1)
        imgT1 = sitk.GetArrayFromImage(imgT1_Org)
        label_Org = sitk.ReadImage(f_L)
        labelimg = sitk.GetArrayFromImage(label_Org)
        fileID='%d'%idn
        rate = 1
        cubicCnt,matplot = cropCubic(imgT1,labelimg,fileID,dFA,step,rate,TrainDataPath)

        volOut = sitk.GetImageFromArray(matplot)
        volOut.SetDirection(label_Org.GetDirection())
        volOut.SetOrigin(label_Org.GetOrigin())
        volOut.SetSpacing(label_Org.GetSpacing())

        sitk.WriteImage(volOut,'./%s_plotpart.nii.gz'%subject_name)

    print('done')
if __name__ == '__main__':
    main()
