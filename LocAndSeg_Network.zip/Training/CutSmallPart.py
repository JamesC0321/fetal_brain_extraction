import SimpleITK as sitk
from multiprocessing import Pool
import os
import h5py
import numpy as np
import scipy.io as scio
from scipy import ndimage as nd
from skimage.morphology import remove_small_objects
from skimage.morphology import remove_small_holes

def calculatepoint(img,imglabel):
    #return img
    [row,col,leng] = img.shape   # read the size of matT1.
    row1 = row/6
    col1 = col/6
    leng1 = leng/6

    matimg = np.zeros([row1*2,col1*2,leng1*2],dtype = np.int16)
    matlabel = np.zeros([row1*2,col1*2,leng1*2],dtype = np.uint8)
    num = 0
    midrow = 0
    midcol = 0
    midleng = 0

    for i in range(0, row, 1):
        for j in range(0, col, 1):
            for k in range(0, leng, 1):
            	if imglabel(i,j,k) == 1:
            		num = int32(num + 1)
            		midrow = int32(midrow + i)
            		midcol = int32(midcol + j)
            		midleng = int32(midleng + k)

    midrow = midrow/num
    midcol = midcol/num
    midleng = minleng/num

    if (midrow - row1) < 0:
    	rowleft = 0
    else:
    	rowleft = midrow - row1

    if (midrow + row1) > row:
    	rowright = row
    else:
    	rowright = midrow + row1

    if (midcol - col1) < 0:
    	colleft = 0
    else:
    	colleft = midcol - col1

    if (midcol + col1) > col:
    	colright = col
    else:
    	colright = midcol + col1

    if (midleng - leng1) < 0:
    	lengleft = 0
    else:
    	lengleft = midleng - leng1

    if (midleng + leng1) > leng1:
    	lengright = leng
    else:
    	lengright = midleng + leng1

    disrow = row1*2 - (rowright - rowleft)
    discol = col1*2 - (colright - colleft)
    disleng = leng1*2 - (lengright - lengright)

    matimg[disrow/2:[dirow/2+[rowright - rowleft]],discol/2:[discol/2+[colright - colleft]],disleng/2:[disleng/2+[lengright - lengleft]]] = img[rowleft:rowright,colleft:colright,lengleft:lengright]
    matlabel[disrow/2:[dirow/2+[rowright - rowleft]],discol/2:[discol/2+[colright - colleft]],disleng/2:[disleng/2+[lengright - lengleft]]] = imglabel[rowleft:rowright,colleft:colright,lengleft:lengright]
    
    return matimg, matlabel

def main():

    data_path = '***/Your data path here/***'
    items = os.listdir(".")
    newlist = []
    ids = set()
    for names in items:
        if names.endswith("_resize_n4.nii.gz"):
            newlist.append(names)

    for f in newlist:
        ids.add(f.split('_resize_n4.nii.gz')[0])
    ids = list(ids)
    print ids

    for idn in range(len(ids)):
        subject_name = ids[idn]
        print(subject_name)

        f_Img1 = os.path.join(data_path,'%s_resize_n4.nii.gz'%subject_name);
        img1_Org = sitk.ReadImage(f_Img1)
        img1 = sitk.GetArrayFromImage(img1_Org)

        f_label = os.path.join(data_path,'%s-label.nii.gz'%subject_name);
        label_Org = sitk.ReadImage(f_label)
        label1 = sitk.GetArrayFromImage(label_Org)

        Out,Out1 = calculatepoint(img1,label1)
        Out.SetDirection(img1_Org.GetDirection())
        Out.SetOrigin(img1_Org.GetOrigin())
        Out.SetSpacing(img1_Org.GetSpacing())
        sitk.WriteImage(Out,'./%s_resize_n4_part.nii.gz'%subject_name)

        Out1.SetDirection(label_Org.GetDirection())
        Out1.SetOrigin(label_Org.GetOrigin())
        Out1.SetSpacing(label_Org.GetSpacing())
        sitk.WriteImage(Out1,'./%s-label_part.nii.gz'%subject_name)

if __name__ == '__main__':
    main()